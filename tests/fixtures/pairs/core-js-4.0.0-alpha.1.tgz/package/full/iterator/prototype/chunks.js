'use strict';
require('../../../modules/es.object.to-string');
require('../../../modules/es.iterator.constructor');
require('../../../modules/esnext.iterator.chunks');

var getBuiltInPrototypeMethod = require('../../../internals/get-built-in-prototype-method');

module.exports = getBuiltInPrototypeMethod('Iterator', 'chunks');
