'use strict';
require('../../modules/es.object.to-string');
require('../../modules/es.array.iterator');
require('../../modules/es.string.from-code-point');
require('../../modules/es.string.iterator');
require('../../modules/es.weak-map.constructor');
require('../../modules/esnext.string.dedent');
require('../../modules/web.dom-collections.iterator');

var getBuiltInStaticMethod = require('../../internals/get-built-in-static-method');

module.exports = getBuiltInStaticMethod('String', 'dedent');
