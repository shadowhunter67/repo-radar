'use strict';
require('../../modules/esnext.string.cooked');

var getBuiltInStaticMethod = require('../../internals/get-built-in-static-method');

module.exports = getBuiltInStaticMethod('String', 'cooked');
