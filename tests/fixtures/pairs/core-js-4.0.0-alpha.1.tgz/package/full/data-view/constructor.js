'use strict';
require('../../modules/es.object.to-string');
require('../../modules/es.math.log2');
require('../../modules/es.data-view.constructor');
require('../../modules/es.data-view.set-int8');
require('../../modules/es.data-view.set-uint8');
require('../../modules/es.data-view.get-float16');
require('../../modules/es.data-view.set-float16');
require('../../modules/es.data-view.to-string-tag');
require('../../modules/esnext.data-view.get-uint8-clamped');
require('../../modules/esnext.data-view.set-uint8-clamped');

var path = require('../../internals/path');

module.exports = path.DataView;
