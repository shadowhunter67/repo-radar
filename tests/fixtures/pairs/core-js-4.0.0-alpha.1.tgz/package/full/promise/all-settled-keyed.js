'use strict';
require('../../modules/es.object.to-string');
require('../../modules/es.reflect.own-keys');
require('../../modules/es.promise.constructor');
require('../../modules/es.promise.catch');
require('../../modules/es.promise.finally');
require('../../modules/es.promise.resolve');
require('../../modules/esnext.promise.all-settled-keyed');

var getBuiltIn = require('../../internals/get-built-in');
var getBuiltInStaticMethod = require('../../internals/get-built-in-static-method');
var isCallable = require('../../internals/is-callable');
var call = require('../../internals/function-call');

var method = getBuiltInStaticMethod('Promise', 'allSettledKeyed');

module.exports = function allSettledKeyed(arg0) {
  return call(method, isCallable(this) ? this : getBuiltIn('Promise'), arg0);
};
