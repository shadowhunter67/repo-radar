'use strict';
var isPrototypeOf = require('../../internals/object-is-prototype-of');
var functionMethod = require('../function/prototype/demethodize');

var FunctionPrototype = Function.prototype;

module.exports = function (it) {
  var ownProperty = it.demethodize;
  if (it === FunctionPrototype || (isPrototypeOf(FunctionPrototype, it) && ownProperty === FunctionPrototype.demethodize)) {
    return functionMethod;
  } return ownProperty;
};
