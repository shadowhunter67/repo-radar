'use strict';
require('../../modules/esnext.symbol.custom-matcher');

var getBuiltInStaticMethod = require('../../internals/get-built-in-static-method');

module.exports = getBuiltInStaticMethod('Symbol', 'customMatcher');
