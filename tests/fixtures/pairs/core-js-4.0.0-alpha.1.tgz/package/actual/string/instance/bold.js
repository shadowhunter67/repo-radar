'use strict';
var isPrototypeOf = require('../../../internals/object-is-prototype-of');
var stringMethod = require('../../string/prototype/bold');

var StringPrototype = String.prototype;

module.exports = function (it) {
  var ownProperty = it.bold;
  if (typeof it == 'string' || it === StringPrototype
    || (isPrototypeOf(StringPrototype, it) && ownProperty === StringPrototype.bold)) return stringMethod;
  return ownProperty;
};
