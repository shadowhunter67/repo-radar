'use strict';
var isPrototypeOf = require('../../../internals/object-is-prototype-of');
var stringMethod = require('../../string/prototype/big');

var StringPrototype = String.prototype;

module.exports = function (it) {
  var ownProperty = it.big;
  if (typeof it == 'string' || it === StringPrototype
    || (isPrototypeOf(StringPrototype, it) && ownProperty === StringPrototype.big)) return stringMethod;
  return ownProperty;
};
