'use strict';
var isPrototypeOf = require('../../../internals/object-is-prototype-of');
var stringMethod = require('../../string/prototype/blink');

var StringPrototype = String.prototype;

module.exports = function (it) {
  var ownProperty = it.blink;
  if (typeof it == 'string' || it === StringPrototype
    || (isPrototypeOf(StringPrototype, it) && ownProperty === StringPrototype.blink)) return stringMethod;
  return ownProperty;
};
