'use strict';
var isPrototypeOf = require('../../../internals/object-is-prototype-of');
var stringMethod = require('../../string/prototype/ends-with');

var StringPrototype = String.prototype;

module.exports = function (it) {
  var ownProperty = it.endsWith;
  if (typeof it == 'string' || it === StringPrototype
    || (isPrototypeOf(StringPrototype, it) && ownProperty === StringPrototype.endsWith)) return stringMethod;
  return ownProperty;
};
