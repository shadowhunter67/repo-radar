'use strict';
var isPrototypeOf = require('../../../internals/object-is-prototype-of');
var stringMethod = require('../../string/prototype/code-point-at');

var StringPrototype = String.prototype;

module.exports = function (it) {
  var ownProperty = it.codePointAt;
  if (typeof it == 'string' || it === StringPrototype
    || (isPrototypeOf(StringPrototype, it) && ownProperty === StringPrototype.codePointAt)) return stringMethod;
  return ownProperty;
};
