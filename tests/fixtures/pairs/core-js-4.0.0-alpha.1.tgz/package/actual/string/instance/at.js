'use strict';
var isPrototypeOf = require('../../../internals/object-is-prototype-of');
var stringMethod = require('../../string/prototype/at');

var StringPrototype = String.prototype;

module.exports = function (it) {
  var ownProperty = it.at;
  if (typeof it == 'string' || it === StringPrototype
    || (isPrototypeOf(StringPrototype, it) && ownProperty === StringPrototype.at)) return stringMethod;
  return ownProperty;
};
