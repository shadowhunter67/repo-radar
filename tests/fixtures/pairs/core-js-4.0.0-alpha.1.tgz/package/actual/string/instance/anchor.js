'use strict';
var isPrototypeOf = require('../../../internals/object-is-prototype-of');
var stringMethod = require('../../string/prototype/anchor');

var StringPrototype = String.prototype;

module.exports = function (it) {
  var ownProperty = it.anchor;
  if (typeof it == 'string' || it === StringPrototype
    || (isPrototypeOf(StringPrototype, it) && ownProperty === StringPrototype.anchor)) return stringMethod;
  return ownProperty;
};
