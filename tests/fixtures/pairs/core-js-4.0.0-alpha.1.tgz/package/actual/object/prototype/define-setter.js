'use strict';
require('../../../modules/es.object.define-setter');

var getBuiltInPrototypeMethod = require('../../../internals/get-built-in-prototype-method');

module.exports = getBuiltInPrototypeMethod('Object', '__defineSetter__');
