'use strict';
require('../../../modules/es.object.define-getter');

var getBuiltInPrototypeMethod = require('../../../internals/get-built-in-prototype-method');

module.exports = getBuiltInPrototypeMethod('Object', '__defineGetter__');
