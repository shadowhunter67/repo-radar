'use strict';
var getBuiltInStaticMethod = require('../../internals/get-built-in-static-method');
var call = require('../../internals/function-call');

module.exports = function defineProperty(arg0, arg1, arg2) {
  return call(getBuiltInStaticMethod('Object', 'defineProperty'), this, arg0, arg1, arg2);
};
