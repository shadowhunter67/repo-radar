'use strict';
require('../../modules/es.object.assign');

var getBuiltInStaticMethod = require('../../internals/get-built-in-static-method');

module.exports = getBuiltInStaticMethod('Object', 'assign');
