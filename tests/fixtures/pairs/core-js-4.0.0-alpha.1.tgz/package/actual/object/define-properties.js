'use strict';
var getBuiltInStaticMethod = require('../../internals/get-built-in-static-method');
var call = require('../../internals/function-call');

module.exports = function defineProperties(arg0, arg1) {
  return call(getBuiltInStaticMethod('Object', 'defineProperties'), this, arg0, arg1);
};
