'use strict';
var getBuiltInStaticMethod = require('../../internals/get-built-in-static-method');
var call = require('../../internals/function-call');

module.exports = function create(arg0, arg1) {
  return call(getBuiltInStaticMethod('Object', 'create'), this, arg0, arg1);
};
