'use strict';
require('../../modules/es.object.to-string');
require('../../modules/es.array-buffer.constructor');
require('../../modules/es.array-buffer.slice');
require('../../modules/es.array-buffer.detached');
require('../../modules/es.array-buffer.transfer');
require('../../modules/es.array-buffer.transfer-to-fixed-length');
require('../../modules/es.array-buffer.species');
require('../../modules/es.array-buffer.to-string-tag');

var path = require('../../internals/path');

module.exports = path.ArrayBuffer;
