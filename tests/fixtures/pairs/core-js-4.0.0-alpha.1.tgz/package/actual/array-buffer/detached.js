'use strict';
require('../../modules/es.array-buffer.detached');
