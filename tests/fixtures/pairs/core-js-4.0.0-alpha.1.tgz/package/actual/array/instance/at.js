'use strict';
var isPrototypeOf = require('../../../internals/object-is-prototype-of');
var arrayMethod = require('../../array/prototype/at');

var ArrayPrototype = Array.prototype;

module.exports = function (it) {
  var ownProperty = it.at;
  if (it === ArrayPrototype || (isPrototypeOf(ArrayPrototype, it) && ownProperty === ArrayPrototype.at)) return arrayMethod;
  return ownProperty;
};
