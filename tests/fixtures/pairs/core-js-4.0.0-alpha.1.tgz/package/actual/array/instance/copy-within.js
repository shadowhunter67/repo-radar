'use strict';
var isPrototypeOf = require('../../../internals/object-is-prototype-of');
var arrayMethod = require('../../array/prototype/copy-within');

var ArrayPrototype = Array.prototype;

module.exports = function (it) {
  var ownProperty = it.copyWithin;
  if (it === ArrayPrototype || (isPrototypeOf(ArrayPrototype, it) && ownProperty === ArrayPrototype.copyWithin)) return arrayMethod;
  return ownProperty;
};
