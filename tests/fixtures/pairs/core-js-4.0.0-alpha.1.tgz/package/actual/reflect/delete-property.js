'use strict';
require('../../modules/es.reflect.delete-property');

var getBuiltInStaticMethod = require('../../internals/get-built-in-static-method');

module.exports = getBuiltInStaticMethod('Reflect', 'deleteProperty');
