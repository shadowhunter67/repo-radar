'use strict';
require('../../modules/es.reflect.apply');

var getBuiltInStaticMethod = require('../../internals/get-built-in-static-method');

module.exports = getBuiltInStaticMethod('Reflect', 'apply');
