'use strict';
require('../../modules/es.reflect.construct');

var getBuiltInStaticMethod = require('../../internals/get-built-in-static-method');

module.exports = getBuiltInStaticMethod('Reflect', 'construct');
