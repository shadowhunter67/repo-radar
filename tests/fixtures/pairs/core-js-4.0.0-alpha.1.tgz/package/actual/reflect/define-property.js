'use strict';
require('../../modules/es.reflect.define-property');

var getBuiltInStaticMethod = require('../../internals/get-built-in-static-method');

module.exports = getBuiltInStaticMethod('Reflect', 'defineProperty');
