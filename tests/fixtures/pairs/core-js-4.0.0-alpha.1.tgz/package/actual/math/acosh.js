'use strict';
require('../../modules/es.math.acosh');

var getBuiltInStaticMethod = require('../../internals/get-built-in-static-method');

module.exports = getBuiltInStaticMethod('Math', 'acosh');
