'use strict';
require('../../modules/es.math.atanh');

var getBuiltInStaticMethod = require('../../internals/get-built-in-static-method');

module.exports = getBuiltInStaticMethod('Math', 'atanh');
