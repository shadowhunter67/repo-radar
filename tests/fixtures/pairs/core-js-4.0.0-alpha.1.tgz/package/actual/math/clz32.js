'use strict';
require('../../modules/es.math.clz32');

var getBuiltInStaticMethod = require('../../internals/get-built-in-static-method');

module.exports = getBuiltInStaticMethod('Math', 'clz32');
