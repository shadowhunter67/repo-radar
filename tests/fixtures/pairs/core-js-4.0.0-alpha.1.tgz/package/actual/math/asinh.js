'use strict';
require('../../modules/es.math.asinh');

var getBuiltInStaticMethod = require('../../internals/get-built-in-static-method');

module.exports = getBuiltInStaticMethod('Math', 'asinh');
