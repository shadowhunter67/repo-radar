'use strict';
require('../../modules/es.math.cosh');

var getBuiltInStaticMethod = require('../../internals/get-built-in-static-method');

module.exports = getBuiltInStaticMethod('Math', 'cosh');
