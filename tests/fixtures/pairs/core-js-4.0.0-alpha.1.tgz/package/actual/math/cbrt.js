'use strict';
require('../../modules/es.math.cbrt');

var getBuiltInStaticMethod = require('../../internals/get-built-in-static-method');

module.exports = getBuiltInStaticMethod('Math', 'cbrt');
