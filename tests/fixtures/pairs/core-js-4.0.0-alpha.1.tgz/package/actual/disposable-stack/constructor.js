'use strict';
require('../../modules/es.object.to-string');
require('../../modules/es.suppressed-error.constructor');
require('../../modules/es.disposable-stack.constructor');
require('../../modules/es.iterator.dispose');

var path = require('../../internals/path');

module.exports = path.DisposableStack;
