'use strict';
require('../../modules/es.object.assign');
require('../../modules/es.object.to-string');
require('../../modules/es.array.iterator');
require('../../modules/es.array.from');
require('../../modules/es.string.from-code-point');
require('../../modules/es.string.iterator');
require('../../modules/web.dom-collections.iterator');
require('../../modules/web.url.constructor');
require('../../modules/web.url.to-json');
require('../../modules/web.url-search-params.constructor');
require('../../modules/web.url-search-params.delete');
require('../../modules/web.url-search-params.has');
require('../../modules/web.url-search-params.size');

var path = require('../../internals/path');

module.exports = path.URL;
