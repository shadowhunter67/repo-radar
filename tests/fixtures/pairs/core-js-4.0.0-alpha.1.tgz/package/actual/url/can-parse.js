'use strict';
require('../../modules/es.object.assign');
require('../../modules/es.object.to-string');
require('../../modules/es.array.iterator');
require('../../modules/es.array.from');
require('../../modules/es.string.from-code-point');
require('../../modules/es.string.iterator');
require('../../modules/web.dom-collections.iterator');
require('../../modules/web.url.constructor');
require('../../modules/web.url.can-parse');
require('../../modules/web.url-search-params.constructor');

var getBuiltInStaticMethod = require('../../internals/get-built-in-static-method');

module.exports = getBuiltInStaticMethod('URL', 'canParse');
