'use strict';
require('../../modules/es.object.to-string');
require('../../modules/es.aggregate-error.constructor');
require('../../modules/es.promise.constructor');
require('../../modules/es.promise.catch');
require('../../modules/es.promise.finally');
require('../../modules/es.promise.resolve');
require('../../modules/es.promise.any');
require('../../modules/es.array.iterator');
require('../../modules/es.string.iterator');
require('../../modules/web.dom-collections.iterator');

var getBuiltIn = require('../../internals/get-built-in');
var getBuiltInStaticMethod = require('../../internals/get-built-in-static-method');
var isCallable = require('../../internals/is-callable');
var call = require('../../internals/function-call');

var method = getBuiltInStaticMethod('Promise', 'any');

module.exports = function any(arg0) {
  return call(method, isCallable(this) ? this : getBuiltIn('Promise'), arg0);
};
