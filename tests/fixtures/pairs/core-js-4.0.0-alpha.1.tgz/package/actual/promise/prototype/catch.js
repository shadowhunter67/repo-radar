'use strict';
require('../../../modules/es.object.to-string');
require('../../../modules/es.promise.constructor');
require('../../../modules/es.promise.catch');

var getBuiltInPrototypeMethod = require('../../../internals/get-built-in-prototype-method');

module.exports = getBuiltInPrototypeMethod('Promise', 'catch');
