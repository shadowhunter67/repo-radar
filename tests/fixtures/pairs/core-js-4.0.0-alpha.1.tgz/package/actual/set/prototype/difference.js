'use strict';
require('../../../modules/es.object.to-string');
require('../../../modules/es.array.iterator');
require('../../../modules/es.set.constructor');
require('../../../modules/es.set.difference');
require('../../../modules/es.string.iterator');
require('../../../modules/web.dom-collections.iterator');

var getBuiltInPrototypeMethod = require('../../../internals/get-built-in-prototype-method');

module.exports = getBuiltInPrototypeMethod('Set', 'difference');
