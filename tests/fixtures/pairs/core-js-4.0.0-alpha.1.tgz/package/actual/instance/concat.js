'use strict';
var isPrototypeOf = require('../../internals/object-is-prototype-of');
var arrayMethod = require('../array/prototype/concat');

var ArrayPrototype = Array.prototype;

module.exports = function (it) {
  var ownProperty = it.concat;
  if (it === ArrayPrototype || (isPrototypeOf(ArrayPrototype, it) && ownProperty === ArrayPrototype.concat)) return arrayMethod;
  return ownProperty;
};
