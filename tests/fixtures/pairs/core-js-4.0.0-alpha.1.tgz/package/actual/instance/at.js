'use strict';
var isPrototypeOf = require('../../internals/object-is-prototype-of');
var arrayMethod = require('../array/prototype/at');
var stringMethod = require('../string/prototype/at');

var ArrayPrototype = Array.prototype;
var StringPrototype = String.prototype;

module.exports = function (it) {
  var ownProperty = it.at;
  if (it === ArrayPrototype || (isPrototypeOf(ArrayPrototype, it) && ownProperty === ArrayPrototype.at)) return arrayMethod;
  if (typeof it == 'string' || it === StringPrototype
    || (isPrototypeOf(StringPrototype, it) && ownProperty === StringPrototype.at)) return stringMethod;
  return ownProperty;
};
