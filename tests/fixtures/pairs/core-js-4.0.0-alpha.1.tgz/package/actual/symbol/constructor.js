'use strict';
require('../../modules/es.symbol.constructor');
require('../../modules/es.symbol.description');
require('../../modules/es.object.to-string');

var path = require('../../internals/path');

module.exports = path.Symbol;
