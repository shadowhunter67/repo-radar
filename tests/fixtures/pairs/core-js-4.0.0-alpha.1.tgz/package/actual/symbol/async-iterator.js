'use strict';
require('../../modules/es.symbol.async-iterator');

var getBuiltInStaticMethod = require('../../internals/get-built-in-static-method');

module.exports = getBuiltInStaticMethod('Symbol', 'asyncIterator');
