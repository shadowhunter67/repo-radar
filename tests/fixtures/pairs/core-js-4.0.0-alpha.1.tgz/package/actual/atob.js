'use strict';
require('../modules/es.object.to-string');
require('../modules/web.dom-exception.constructor');
require('../modules/web.dom-exception.stack');
require('../modules/web.dom-exception.to-string-tag');
require('../modules/web.atob');

var path = require('../internals/path');

module.exports = path.atob;
