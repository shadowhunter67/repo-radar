'use strict';
require('../../modules/es.object.to-string');
require('../../modules/es.aggregate-error.constructor');
require('../../modules/es.aggregate-error.cause');
require('../../modules/es.array.iterator');
require('../../modules/es.string.iterator');
require('../../modules/web.dom-collections.iterator');

var path = require('../../internals/path');

module.exports = path.AggregateError;
