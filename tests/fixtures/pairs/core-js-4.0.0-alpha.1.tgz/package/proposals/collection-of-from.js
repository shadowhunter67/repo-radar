'use strict';
// proposal stage: 1
// https://github.com/tc39/proposal-setmap-offrom
require('../modules/es.object.to-string');
require('../modules/es.array.iterator');
require('../modules/es.map.constructor');
require('../modules/es.set.constructor');
require('../modules/es.string.iterator');
require('../modules/es.weak-map.constructor');
require('../modules/es.weak-set.constructor');
require('../modules/esnext.map.from');
require('../modules/esnext.map.of');
require('../modules/esnext.set.from');
require('../modules/esnext.set.of');
require('../modules/esnext.weak-map.from');
require('../modules/esnext.weak-map.of');
require('../modules/esnext.weak-set.from');
require('../modules/esnext.weak-set.of');
require('../modules/web.dom-collections.iterator');
