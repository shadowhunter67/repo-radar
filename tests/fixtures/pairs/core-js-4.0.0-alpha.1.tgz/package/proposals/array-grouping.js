'use strict';
// proposal stage: 4
// https://github.com/tc39/proposal-array-grouping
require('../modules/es.object.group-by');
require('../modules/es.object.to-string');
require('../modules/es.array.iterator');
require('../modules/es.map.constructor');
require('../modules/es.map.group-by');
require('../modules/es.string.iterator');
require('../modules/web.dom-collections.iterator');
