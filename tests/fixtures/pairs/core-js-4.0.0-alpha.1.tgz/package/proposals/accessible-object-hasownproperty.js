'use strict';
// proposal stage: 4
// https://github.com/tc39/proposal-accessible-object-hasownproperty
require('../modules/es.object.has-own');
