'use strict';
// proposal stage: 4
// https://github.com/tc39/proposal-async-iteration
require('../modules/es.symbol.async-iterator');
