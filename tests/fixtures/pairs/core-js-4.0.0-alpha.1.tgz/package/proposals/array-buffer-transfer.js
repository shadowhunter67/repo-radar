'use strict';
// proposal stage: 4
// https://github.com/tc39/proposal-arraybuffer-transfer
require('../modules/es.array-buffer.slice');
require('../modules/es.array-buffer.detached');
require('../modules/es.array-buffer.transfer');
require('../modules/es.array-buffer.transfer-to-fixed-length');
